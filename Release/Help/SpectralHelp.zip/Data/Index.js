CMCXmlParser._FilePathToXmlStringMap.Add(
	'Index',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultTargetIndex Count=\"69\">' +
	'    <IndexEntry>' +
	'        <Entries>' +
	'            <IndexEntry Term=\"ACE\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"About the Adaptive Cosine Estimator\" Link=\"/Content/Material_ID/About_the_Adaptive_Cosine_Estimator.htm#kanchor31\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Adaptive Cosine Estimator\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"About the Adaptive Cosine Estimator\" Link=\"/Content/Material_ID/About_the_Adaptive_Cosine_Estimator.htm#kanchor31\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Anomaly Detector RX\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"RX Anomaly Detector\" Link=\"/Content/Anomaly_Detectors/RX_Anomaly_Detector.htm#kanchor38\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"AOI Average Signature\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Display the AOI Average Signature\" Link=\"/Content/Signature_Window_Plug-In/Display_AOI_Average_Signature.htm#kanchor44\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"AOI Signatures\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Display AOI Signatures and the AOI Average Signature\" Link=\"/Content/Signature_Window_Plug-In/Display AOI Signatures.htm#kanchor43\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"ASTER Spectral Signature Importer\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"ASTER Spectral Signature Importer\" Link=\"/Content/Importers/aster_spectral_signature_importer.htm#kanchor2\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"CEM\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Constrained Energy Minimization (CEM)\" Link=\"/Content/Material_ID/constrained_energy_minimization_(cem).htm#kanchor29\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"configuration settings, Signature Window\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Signature Window Configuration Settings\" Link=\"/Content/Signature_Window_Plug-In/Signature_Window_Configuration_Settings.htm#kanchor45\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Constrained Energy Minimization\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Constrained Energy Minimization (CEM)\" Link=\"/Content/Material_ID/constrained_energy_minimization_(cem).htm#kanchor30\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"DG Importer\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"DG Importer\" Link=\"/Content/Importers/DG_Importer.htm#kanchor3\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Digital Globe Importer Options\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Digital Globe Importer Options\" Link=\"/Content/Importers/Digital_Globe_Importer_Options.htm#kanchor4\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"DigitalGlobe Importer\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"DG Importer\" Link=\"/Content/Importers/DG_Importer.htm#kanchor3\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Display AOI Average Signature\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Display the AOI Average Signature\" Link=\"/Content/Signature_Window_Plug-In/Display_AOI_Average_Signature.htm#kanchor44\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Display AOI Signatures\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Display AOI Signatures and the AOI Average Signature\" Link=\"/Content/Signature_Window_Plug-In/Display AOI Signatures.htm#kanchor43\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Display Pixel Signature\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Display Pixel Signature\" Link=\"/Content/Signature_Window_Plug-In/Display_Pixel_Signature.htm#kanchor42\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"ELM\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Empirical Line Method (ELM) Calibration\" Link=\"/Content/Preprocessing/empirical_line_method_(elm)_calibration.htm#kanchor14\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Exporters\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Signature Exporter\" Link=\"/Content/Exporters/signature_exporter.htm#kanchor47\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                    <IndexLink Title=\"Spectral Signature Library Exporter\" Link=\"/Content/Exporters/spectral_signature_library_exporter.htm#kanchor48\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"IARR\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"IARR\" Link=\"/Content/Preprocessing/IARR.htm#kanchor15\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Importers\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"ASTER Spectral Signature Importer\" Link=\"/Content/Importers/aster_spectral_signature_importer.htm#kanchor2\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                    <IndexLink Title=\"DG Importer\" Link=\"/Content/Importers/DG_Importer.htm#kanchor3\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                    <IndexLink Title=\"Landsat GeoTIFF Importer\" Link=\"/Content/Importers/Landsat_GeoTIFF_Importer.htm#kanchor5\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                    <IndexLink Title=\"Landsat ETM+ Importer\" Link=\"/Content/Importers/landsat_etm+_importer.htm#kanchor7\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                    <IndexLink Title=\"Landsat TM Importer\" Link=\"/Content/Importers/landsat_tm_importer.htm#kanchor9\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                    <IndexLink Title=\"Signature Importer\" Link=\"/Content/Importers/signature_importer.htm#kanchor11\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                    <IndexLink Title=\"Spectral Signature Library Importer\" Link=\"/Content/Importers/spectral_signature_library_importer.htm#kanchor12\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Landsat ETM+ Importer\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Landsat ETM+ Importer\" Link=\"/Content/Importers/landsat_etm+_importer.htm#kanchor8\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Landsat GeoTIFF Importer\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Landsat GeoTIFF Importer\" Link=\"/Content/Importers/Landsat_GeoTIFF_Importer.htm#kanchor5\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Landsat GeoTIFF Importer options\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Landsat GeoTIFF Importer Options\" Link=\"/Content/Importers/Landsat_GeoTIFF_Importer_Options.htm#kanchor6\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Landsat TM Importer\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Landsat TM Importer\" Link=\"/Content/Importers/landsat_tm_importer.htm#kanchor10\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Minimum Noise Fraction Transform\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"MNF Transform\" Link=\"/Content/Exploitation_Tools/MNF_Transform.htm#kanchor26\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"MNF Forward Transform\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"MNF Transform\" Link=\"/Content/Exploitation_Tools/MNF_Forward.htm#kanchor27\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"MNF Inverse Transform\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"MNF Inverse Transform\" Link=\"/Content/Exploitation_Tools/MNF_Inverse.htm#kanchor28\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"MNF Transform\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"MNF Transform\" Link=\"/Content/Exploitation_Tools/MNF_Transform.htm#kanchor26\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Options\">' +
	'                <Entries>' +
	'                    <IndexEntry Term=\"Digital Globe Importer\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Digital Globe Importer Options\" Link=\"/Content/Importers/Digital_Globe_Importer_Options.htm#kanchor4\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"Landsat GeoTIFF Importer\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Landsat GeoTIFF Importer Options\" Link=\"/Content/Importers/Landsat_GeoTIFF_Importer_Options.htm#kanchor6\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"Signature Window\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Signature Window Configuration Settings\" Link=\"/Content/Signature_Window_Plug-In/Signature_Window_Configuration_Settings.htm#kanchor45\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"Spectral Library Match\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Spectral Library Match Options\" Link=\"/Content/Material_ID/Spectral_Library_Match/SLM_Options.htm#kanchor35\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                </Entries>' +
	'                <Links />' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Pin/Unpin Signature Window\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Pin/Unpin Signature Window\" Link=\"/Content/Signature_Window_Plug-In/Pin_Unpin_Signature_Window.htm#kanchor41\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Pixel Signature\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Display Pixel Signature\" Link=\"/Content/Signature_Window_Plug-In/Display_Pixel_Signature.htm#kanchor42\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Profile Plots\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Working With Plot Profiles\" Link=\"/Content/Exploitation_Tools/Working_With_Plot_Profiles.htm#kanchor25\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Range Profiles\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Range Profiles\" Link=\"/Content/Exploitation_Tools/Range_Profiles.htm#kanchor24\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"RX Anomaly Detector\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"RX Anomaly Detector\" Link=\"/Content/Anomaly_Detectors/RX_Anomaly_Detector.htm#kanchor38\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"SAM\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Spectral Angle Mapper (SAM)\" Link=\"/Content/Material_ID/spectral_angle_mapper_(sam).htm#kanchor33\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Signature Exporter\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Signature Exporter\" Link=\"/Content/Exporters/signature_exporter.htm#kanchor47\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Signature Importer\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Signature Importer\" Link=\"/Content/Importers/signature_importer.htm#kanchor11\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Signature Window\">' +
	'                <Entries>' +
	'                    <IndexEntry Term=\"configuration settings\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Signature Window Configuration Settings\" Link=\"/Content/Signature_Window_Plug-In/Signature_Window_Configuration_Settings.htm#kanchor46\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"options\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Signature Window Configuration Settings\" Link=\"/Content/Signature_Window_Plug-In/Signature_Window_Configuration_Settings.htm#kanchor46\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"Pin\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Pin/Unpin Signature Window\" Link=\"/Content/Signature_Window_Plug-In/Pin_Unpin_Signature_Window.htm#kanchor41\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"Unpin\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Pin/Unpin Signature Window\" Link=\"/Content/Signature_Window_Plug-In/Pin_Unpin_Signature_Window.htm#kanchor41\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                </Entries>' +
	'                <Links />' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Signature Window Plug-in\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Signature Window Plug-In\" Link=\"/Content/Signature_Window_Plug-In/Signature_Window_Plug_In.htm#kanchor40\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Signatures\">' +
	'                <Entries>' +
	'                    <IndexEntry Term=\"AOI\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Display AOI Signatures and the AOI Average Signature\" Link=\"/Content/Signature_Window_Plug-In/Display AOI Signatures.htm#kanchor43\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"AOI Average\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Display the AOI Average Signature\" Link=\"/Content/Signature_Window_Plug-In/Display_AOI_Average_Signature.htm#kanchor44\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"Pixel\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Display Pixel Signature\" Link=\"/Content/Signature_Window_Plug-In/Display_Pixel_Signature.htm#kanchor42\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                </Entries>' +
	'                <Links>' +
	'                    <IndexLink Title=\"Signature Window Plug-In\" Link=\"/Content/Signature_Window_Plug-In/Signature_Window_Plug_In.htm#kanchor40\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Spectral Angle Mapper\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Spectral Angle Mapper (SAM)\" Link=\"/Content/Material_ID/spectral_angle_mapper_(sam).htm#kanchor32\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Spectral Library Builder\">' +
	'                <Entries>' +
	'                    <IndexEntry Term=\"add signatures\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Add Signatures to a Spectral Library\" Link=\"/Content/Exploitation_Tools/Add_Signatures_to_a_Spectral_Library.htm#kanchor19\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"create new library\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Create a New Spectral Library\" Link=\"/Content/Exploitation_Tools/Create_a_New_Spectral_Library.htm#kanchor17\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"delete library\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Delete a Spectral Library\" Link=\"/Content/Exploitation_Tools/Delete_a_Spectral_Library.htm#kanchor21\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"delete signature from library\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Delete a Signature from a Library\" Link=\"/Content/Exploitation_Tools/Delete_a_Signature_from_a_Library.htm#kanchor20\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"load a library\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Load a Spectral Library\" Link=\"/Content/Exploitation_Tools/Load_a_Spectral_Library.htm#kanchor18\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"save a signature\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Save a Signature\" Link=\"/Content/Exploitation_Tools/Save_a_Signature.htm#kanchor22\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                    <IndexEntry Term=\"save a spectral library\">' +
	'                        <Entries />' +
	'                        <Links>' +
	'                            <IndexLink Title=\"Save a Spectral Library\" Link=\"/Content/Exploitation_Tools/Save_a_Spectral_Library.htm#kanchor23\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                        </Links>' +
	'                        <SeeAlsoLinks />' +
	'                        <IndexControlLinks />' +
	'                    </IndexEntry>' +
	'                </Entries>' +
	'                <Links>' +
	'                    <IndexLink Title=\"Spectral Library Builder\" Link=\"/Content/Exploitation_Tools/spectral_library_builder.htm#kanchor16\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Spectral Library Match\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Spectral Library Match\" Link=\"/Content/Material_ID/Spectral_Library_Match/Spectral_Library_Match.htm#kanchor34\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Spectral Library Match advanced interface\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"SLM Advanced Interface\" Link=\"/Content/Material_ID/Spectral_Library_Match/SLM_Advanced_Interface.htm#kanchor37\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Spectral Library Match options\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Spectral Library Match Options\" Link=\"/Content/Material_ID/Spectral_Library_Match/SLM_Options.htm#kanchor35\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Spectral Library Match simple interface\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"SLM Simple Interface\" Link=\"/Content/Material_ID/Spectral_Library_Match/SLM_Simple_Interface.htm#kanchor36\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Spectral Signature Library Exporter\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Spectral Signature Library Exporter\" Link=\"/Content/Exporters/spectral_signature_library_exporter.htm#kanchor49\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Spectral Signature Library Importer\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Spectral Signature Library Importer\" Link=\"/Content/Importers/spectral_signature_library_importer.htm#kanchor13\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Spectral Toolbar\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Spectral Toolbar\" Link=\"/Content/Toolbars/Spectral_Toolbar.htm#kanchor1\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"TAD\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Topological Anomaly Detector\" Link=\"/Content/Anomaly_Detectors/Topological_Anomaly_Detector.htm#kanchor39\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Topological Anomaly Detector\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Topological Anomaly Detector\" Link=\"/Content/Anomaly_Detectors/Topological_Anomaly_Detector.htm#kanchor39\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'            <IndexEntry Term=\"Unpin Signature Window\">' +
	'                <Entries />' +
	'                <Links>' +
	'                    <IndexLink Title=\"Pin/Unpin Signature Window\" Link=\"/Content/Signature_Window_Plug-In/Pin_Unpin_Signature_Window.htm#kanchor41\" UsedConditions=\"\" LocalConditions=\"\" />' +
	'                </Links>' +
	'                <SeeAlsoLinks />' +
	'                <IndexControlLinks />' +
	'            </IndexEntry>' +
	'        </Entries>' +
	'        <Links />' +
	'        <SeeAlsoLinks />' +
	'        <IndexControlLinks />' +
	'    </IndexEntry>' +
	'</CatapultTargetIndex>'
);
