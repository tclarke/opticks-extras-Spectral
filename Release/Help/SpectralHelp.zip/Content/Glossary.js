CMCXmlParser._FilePathToXmlStringMap.Add(
	'Glossary',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<html xmlns:MadCap=\"http://www.madcapsoftware.com/Schemas/MadCap.xsd\" MadCap:disableMasterStylesheet=\"true\" MadCap:tocPath=\"\" MadCap:medium=\"non-print\" MadCap:InPreviewMode=\"false\" MadCap:PreloadImages=\"false\" MadCap:RuntimeFileType=\"Glossary\" MadCap:TargetType=\"WebHelp\" lang=\"en-us\" xml:lang=\"en-us\" MadCap:PathToHelpSystem=\"../\" MadCap:HelpSystemFileName=\"Spectral_Help.xml\">' +
	'    <head>' +
	'        <link href=\"SkinSupport/MadCap.css\" rel=\"stylesheet\" type=\"text/css\" />' +
	'        <title>Glossary</title>' +
	'        <link href=\"Resources/Stylesheets/Opticks_Styles.css\" rel=\"stylesheet\" type=\"text/css\" />' +
	'        <script src=\"SkinSupport/MadCapAll.js\" type=\"text/javascript\">' +
	'        </script>' +
	'    </head>' +
	'    <body style=\"background-color: #fafafa;\">' +
	'        <div id=\"GlossaryBody\">' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_0\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">ACE</a>' +
	'                    <a name=\"973183176_anchor1\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_0\" style=\"display: none;\">Adaptive Cosine Estimator</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_1\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">CEM</a>' +
	'                    <a name=\"973183176_anchor2\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_1\" style=\"display: none;\">Constrained Energy Minimization</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_2\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">DG</a>' +
	'                    <a name=\"973183176_anchor3\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_2\" style=\"display: none;\">Digital Globe</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_3\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">ELM</a>' +
	'                    <a name=\"973183176_anchor4\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_3\" style=\"display: none;\">Empirical Line Method</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_4\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">FWHM</a>' +
	'                    <a name=\"973183176_anchor5\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_4\" style=\"display: none;\">Full Width Half Maximum</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_5\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">IARR</a>' +
	'                    <a name=\"973183176_anchor6\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_5\" style=\"display: none;\">Internal Average Relative Reflectance</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_6\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">MNF</a>' +
	'                    <a name=\"973183176_anchor7\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_6\" style=\"display: none;\">Minimum Noise Fraction</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_7\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">RX</a>' +
	'                    <a name=\"973183176_anchor8\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_7\" style=\"display: none;\">Reed-Xiaoli</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_8\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">SAM</a>' +
	'                    <a name=\"973183176_anchor9\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_8\" style=\"display: none;\">Spectral Angle Mapper</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_9\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">SLM</a>' +
	'                    <a name=\"973183176_anchor10\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_9\" style=\"display: none;\">Spectral Library Match</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_10\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">SNR</a>' +
	'                    <a name=\"973183176_anchor11\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_10\" style=\"display: none;\">Signal to Noise Ratio</div>' +
	'            </div>' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_973183176_11\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">TAD</a>' +
	'                    <a name=\"973183176_anchor12\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_973183176_11\" style=\"display: none;\">Topological Anomaly Detector</div>' +
	'            </div>' +
	'        </div>' +
	'        <p>&#160;</p>' +
	'        <script type=\"text/javascript\" src=\"SkinSupport/MadCapBodyEnd.js\">' +
	'        </script>' +
	'    </body>' +
	'</html>'
);
